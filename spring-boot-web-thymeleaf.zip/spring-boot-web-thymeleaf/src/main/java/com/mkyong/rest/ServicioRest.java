package com.mkyong.rest;

import java.util.Random;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("rest")
public class ServicioRest {
 @GetMapping("/saluda/")
 public ResponseEntity<String> saluda(){
	 Random d=new Random(1000);
	 return new ResponseEntity("hola "+d.nextInt(), new HttpHeaders(), HttpStatus.OK);
 	 
 }
 @GetMapping("/sumar/{n1}/{n2}")
 public ResponseEntity<String> sumar(@RequestParam("n1")int n1,@RequestParam("n2")int n2){
	 
	 return new ResponseEntity(Integer.toString(n1+n2), new HttpHeaders(), HttpStatus.OK);
 }
}
