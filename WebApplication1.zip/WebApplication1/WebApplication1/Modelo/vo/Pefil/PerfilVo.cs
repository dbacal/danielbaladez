﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Modelo.vo
{
    public class PerfilVo
    {
        public short ID { get; set; }
        public String NOMBRE { get; set; }
    }
}