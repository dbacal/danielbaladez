﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Modelo.vo
{
    public class UsuarioVO
    {

        public String  nombre { get; set; }
        public String pass { get; set; }
        public PerfilVo perfil { get; set; }
        public String act { get; set; }
    }
}