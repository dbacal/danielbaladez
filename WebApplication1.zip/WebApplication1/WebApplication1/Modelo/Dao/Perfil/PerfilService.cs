﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication1.Modelo.Dao.Perfil
{
    interface PerfilService
    {
        List<vo.PerfilVo> findAll();
        vo.PerfilVo findByUser(vo.UsuarioVO u);
    }
}
