﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace WebApplication1.Modelo.Dao.Perfil
{
    public class PerfilServiceImpl : PerfilService
    {
        public List<vo.PerfilVo> findAll()
        {
            String url = "";
            if (System.Configuration.ConfigurationManager.ConnectionStrings["con"]!=null)
            {
                url = System.Configuration.ConfigurationManager.ConnectionStrings["con"].
            ConnectionString;
            }
            SqlConnection c = new SqlConnection(url);
            List<vo.PerfilVo> resultado = new List<vo.PerfilVo>();
            c.Open();
            SqlCommand cmd = new SqlCommand("select ID,NOMBRE from perfil", c);
            SqlDataReader DR = cmd.ExecuteReader();
            while (DR.Read())
            {
                vo.PerfilVo pefil = new vo.PerfilVo();
                pefil.ID = DR.GetInt16(1);
                pefil.NOMBRE = DR.GetString(2);
                resultado.Add(pefil);
            }
            return resultado;
            c.Close();
        }

        public vo.PerfilVo findByUser(vo.UsuarioVO u) {
            vo.PerfilVo perfil = new vo.PerfilVo();
            String url = "";
            if (System.Configuration.ConfigurationManager.ConnectionStrings["con"]!=null)
            {
                url = System.Configuration.ConfigurationManager.ConnectionStrings["con"].
            ConnectionString;
            }
            SqlConnection c = new SqlConnection(url);
            c.Open();
            SqlCommand cmd=new SqlCommand("select ID,p.NOMBRE from perfil p inner join Usuario u on p.ID=u.perfilId where u.nombre=@n",c);
            cmd.Parameters.AddWithValue("@n",u.nombre);
            SqlDataReader DR = cmd.ExecuteReader();
            while (DR.Read())
            {
                
                
                perfil.ID = DR.GetInt16(0);
                perfil.NOMBRE = DR.GetString(1);
                
            }
            return perfil;
        }  
    }
}