﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication1.Modelo.Dao.Usuario
{
    public class UsuarioServiceImpl : UsuarioService
    {
        private Perfil.PerfilServiceImpl perfilService;

        public UsuarioServiceImpl()
        {
            perfilService = new Perfil.PerfilServiceImpl();
        }
        public bool login(vo.UsuarioVO u)
        {
            String url = "";
            if (System.Configuration.ConfigurationManager.ConnectionStrings["con"] != null)
            {
                url = System.Configuration.ConfigurationManager.ConnectionStrings["con"].
            ConnectionString;
            }
            SqlConnection c=new SqlConnection(url);
            c.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Usuario WHERE nombre=@N AND pass=@P", c);
            cmd.Parameters.AddWithValue("@N", u.nombre);
            cmd.Parameters.AddWithValue("@P", u.pass);
            bool RESU = cmd.ExecuteReader().Read();
            return RESU;
        }


        public bool activar(vo.UsuarioVO u)
        {
            String url = "";
            if (System.Configuration.ConfigurationManager.ConnectionStrings["con"] != null)
            {
                url = System.Configuration.ConfigurationManager.ConnectionStrings["con"].
            ConnectionString;
            }
            SqlConnection c = new SqlConnection(url);
            c.Open();
            SqlCommand cmd = new SqlCommand("update Usuario set activo=1 where nombre=@n", c);
            cmd.Parameters.AddWithValue("@n", u.nombre);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool desactivar(vo.UsuarioVO u)
        {
            String url = "";
            if (System.Configuration.ConfigurationManager.ConnectionStrings["con"] != null)
            {
                url = System.Configuration.ConfigurationManager.ConnectionStrings["con"].
            ConnectionString;
            }
            SqlConnection c = new SqlConnection(url);
            c.Open();

            SqlCommand cmd = new SqlCommand("update Usuario set activo=0 where nombre=@n", c);
            cmd.Parameters.AddWithValue("@n", u.nombre);
            return cmd.ExecuteNonQuery() > 0;
        }

        public vo.UsuarioVO getByName(string name)
        {

            String url = "";
            if (System.Configuration.ConfigurationManager.ConnectionStrings["con"] != null)
            {
                url = System.Configuration.ConfigurationManager.ConnectionStrings["con"].
            ConnectionString;
            }
            SqlConnection c = new SqlConnection(url);
            c.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Usuario WHERE nombre=@N ", c);
            cmd.Parameters.AddWithValue("@N", name);
            SqlDataReader dr = cmd.ExecuteReader();
            Modelo.vo.UsuarioVO u = new vo.UsuarioVO();
            while (dr.Read())
            {
                u.nombre = dr.GetString(0);
                u.pass = dr.GetString(1);
                u.act = dr.GetString(3);
            }
            return u;
        }
    }
}