﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication1.Modelo.Dao.Usuario
{
    interface UsuarioService
    {
        bool login(vo.UsuarioVO u);
        bool activar(vo.UsuarioVO u);
        bool desactivar(vo.UsuarioVO u);
        vo.UsuarioVO getByName(String name);
    }
}
