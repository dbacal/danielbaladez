﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class login : System.Web.UI.Page
    {
        private Modelo.Dao.Usuario.UsuarioServiceImpl udao;
        private int intents=0, maxIntents=0;
        protected void Page_Load(object sender, EventArgs e)
        {
            maxIntents = Int16.Parse(ConfigurationManager.AppSettings["maxIntents"].ToString());
            udao = new Modelo.Dao.Usuario.UsuarioServiceImpl();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Modelo.vo.UsuarioVO vo=new Modelo.vo.UsuarioVO();
            vo.nombre=this.user.Text;
            vo.pass=this.pass.Text;
            Modelo.vo.UsuarioVO usr = udao.getByName(vo.nombre);
            if(usr.act.Equals("0")){
                Response.Redirect("desactivo.aspx");
            }
            if (Session["intentos"] != null)
            {
                intents = Int16.Parse(Session["intentos"].ToString());
            }
            if(intents==maxIntents){
                udao.desactivar(usr);
            }
            if (udao.login(vo)) 
            {
                
                if (usr.act.Equals("1"))
                {
                    Session.Add("usr", usr);
                    Response.Redirect("principal.aspx", true);
                    
                }

            }
            else
            {
                intents++;
                Session.Add("intentos", intents);
            }
        }
    }
}