﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Modelo.Dao.Perfil;

namespace WebApplication1.Vista
{
    public partial class principal : System.Web.UI.Page
    {
        Modelo.Dao.Perfil.PerfilServiceImpl perfilservice;
        protected void Page_Load(object sender, EventArgs e)
        {
            PerfilServiceImpl perfilservice = new Modelo.Dao.Perfil.PerfilServiceImpl();
            if (Session["usr"] != null)
            {
                Modelo.vo.UsuarioVO u = (Modelo.vo.UsuarioVO)Session["usr"];
                String x = u.nombre;
                this.LblUsu.Text = " " + x;
                Modelo.vo.PerfilVo perfil = perfilservice.findByUser(u);
            }
        }
    }
}